# 千问无水印提取器（浏览器插件）

将 [hope0719/qianwen-video-image-watermark-remover](https://github.com/hope0719/qianwen-video-image-watermark-remover) 的解析逻辑移植为 Chrome / Edge 浏览器插件。

## 功能

- 支持 `activity.qianwen.com/r/...` 分享链接，从页面 SSR 的 `__INITIAL_PROPS__` 中提取无水印图片与视频。
- 支持 `www.qianwen.com/share/chat/...`、`qianwen.my.cn/share/chat/...` 及查询参数形式的对话分享链接，调用 `chat2-api.qianwen.com/api/v1/share/info` 获取无水印媒体。
- 支持从 `www.qianwen.com/chat/...`、`qianwen.com/chat/...`、`qianwen.my.cn/chat/...` 普通对话页直接提取当前页面中的图片和视频。
- 兼容新老两种分享数据格式（`display_list` 与 `resource_infos`）。
- 页面未提供标题时，自动回退为分享 ID 或页面标题，不再只显示“未知”。
- 在千问分享页右侧显示可拖动的悬浮按钮，点击后打开可拖拽的大弹窗。
- 页面弹窗内支持图片/视频预览、勾选下载、全部下载、复制链接，并显示文件名、尺寸和下载状态。
- 大弹窗支持“全部 / 图片 / 视频”分类切换，图片和视频预览分开展示。
- 弹窗标题栏需要按住鼠标才能拖动，不会因鼠标悬停而误移动。
- 下载时弹出全局进度窗口，显示已完成数量和进度条。
- 点击工具栏插件图标会直接解析当前千问分享页，也可粘贴任意千问分享链接进行解析。
- 如果千问页面上没有出现悬浮按钮，点击一次工具栏插件图标即可自动注入悬浮脚本。
- 弹窗内可预览图片/视频，并显示文件名、尺寸、下载状态与进度。
- 图片、视频支持预览、单个下载、全部下载、复制链接。

插件需要读取千问页面接口，并直接下载存储在各 CDN 上的媒体文件，因此安装时会提示获取跨域访问权限；插件代码只会在你点击提取或下载时访问千问分享链接及对应媒体地址。

## 安装

1. 打开 Chrome 或 Edge，进入扩展管理页：
   - Chrome：`chrome://extensions/`
   - Edge：`edge://extensions/`
2. 开启「开发者模式」。
3. 点击「加载已解压的扩展程序」。
4. 选择本目录：`qianwen-watermark-remover-extension`。

安装后打开千问分享页，点击右下角悬浮按钮即可提取；也可以点击浏览器工具栏图标，粘贴分享链接后解析。

## 说明

- 无水印媒体 URL 带有时效参数（如 `auth_key`），过期后无法下载，请尽快保存。
- 视频直接保存为 `.mp4`。
- 本项目仅供学习交流，请遵守千问平台相关协议，勿用于侵权用途。
