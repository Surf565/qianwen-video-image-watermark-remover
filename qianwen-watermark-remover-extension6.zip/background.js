const DEFAULT_HEADERS = {
  accept: "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
  "accept-language": "zh-CN,zh;q=0.9,en;q=0.8"
};

function isActivityLink(url) {
  return /activity\.qianwen\.com/.test(url);
}

function isShareChatLink(url) {
  return /(?:qianwen\.com|qianwen\.my\.cn)\/share\/chat/.test(url);
}

function detectLinkType(url) {
  if (isActivityLink(url)) return "activity";
  if (isShareChatLink(url)) return "share_chat";
  throw new Error("不支持的千问分享链接格式");
}

function getErrorMessage(res, data) {
  if (data && typeof data.message === "string" && data.message) return data.message;
  if (data && typeof data.msg === "string" && data.msg) return data.msg;
  return `请求失败（HTTP ${res.status}）`;
}

function extractShareId(url) {
  try {
    const shareId = new URL(url).searchParams.get("share_id");
    if (shareId) return shareId;
  } catch (error) {
    // 继续尝试从路径提取
  }
  const match = url.match(/\/share\/chat\/([a-zA-Z0-9_-]+)/);
  return match ? match[1] : null;
}

function classifyMediaByUrl(url) {
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    if (/\.(mp4|mov|webm|m4v|avi|mkv)$/.test(pathname)) return "video";
    if (/\.(png|jpe?g|webp|gif|bmp|avif)$/.test(pathname)) return "image";
  } catch (error) {
    // 忽略无效 URL
  }
  return null;
}

function extractHtmlTitle(html) {
  const match = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  if (!match) return "";
  return match[1]
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

async function parseActivityLink(url) {
  const response = await fetch(url, {
    method: "GET",
    redirect: "follow",
    headers: {
      ...DEFAULT_HEADERS,
      origin: "https://activity.qianwen.com",
      referer: url
    }
  });
  if (!response.ok) {
    throw new Error(`无法访问分享页（HTTP ${response.status}）`);
  }

  const html = await response.text();
  const match = html.match(/window\.__INITIAL_PROPS__\s*=\s*(\{[\s\S]*?\});/);
  if (!match) {
    throw new Error("无法从页面中提取 __INITIAL_PROPS__ 数据，链接可能已失效");
  }

  const props = JSON.parse(match[1]);
  const data = props.initialData && props.initialData.data ? props.initialData.data : {};
  const htmlTitle = extractHtmlTitle(html);
  let fallbackShareId = "";
  try {
    fallbackShareId = new URL(url).searchParams.get("shareId") || "";
  } catch (error) {
    // 忽略解析失败
  }
  const result = {
    title: data.title || data.name || data.share_title || htmlTitle || (fallbackShareId ? `分享 ${fallbackShareId}` : "未知"),
    images: [],
    videos: []
  };

  const imagesRaw = Array.isArray(data.images) ? data.images.slice() : [];
  const mainImage = data.image || {};
  if (mainImage.url && !imagesRaw.some((img) => img && img.url === mainImage.url)) {
    imagesRaw.unshift(mainImage);
  }

  for (const img of imagesRaw) {
    if (img && typeof img.url === "string") {
      result.images.push({
        url: img.url,
        width: img.width || null,
        height: img.height || null
      });
    }
  }

  const playInfo = data.playInfo || {};
  if (typeof playInfo.url === "string") {
    result.videos.push({
      url: playInfo.url,
      width: playInfo.videoWidth || null,
      height: playInfo.videoHeight || null
    });
  }

  return result;
}

async function parseShareChatLink(url) {
  const shareId = extractShareId(url);
  if (!shareId) {
    throw new Error("无法从链接中提取 share_id");
  }
  let bizId = "ai_qwen";
  try {
    bizId = new URL(url).searchParams.get("biz_id") || bizId;
  } catch (error) {
    // 保持默认 biz_id
  }

  let pageOrigin = "https://www.qianwen.com";
  try {
    pageOrigin = new URL(url).origin;
  } catch (error) {
    // 保持默认 origin
  }

  const response = await fetch("https://chat2-api.qianwen.com/api/v1/share/info?pr=qwen&fr=mac", {
    method: "POST",
    headers: {
      ...DEFAULT_HEADERS,
      "content-type": "application/json",
      origin: pageOrigin,
      referer: url
    },
    body: JSON.stringify({
      share_id: shareId,
      biz_id: bizId
    })
  });

  let data = {};
  try {
    data = await response.json();
  } catch (error) {
    throw new Error("分享接口返回了无法解析的数据");
  }

  if (!response.ok) {
    throw new Error(getErrorMessage(response, data));
  }

  const session = data.data && data.data.session;
  const records = session && Array.isArray(session.record_list) ? session.record_list : [];
  if (!records.length) {
    throw new Error("分享数据中没有找到媒体内容");
  }

  const result = {
    title:
      (session && (session.title || session.name || session.share_title || session.share_name)) ||
      (data.data && (data.data.title || data.data.name)) ||
      `分享 ${shareId}`,
    images: [],
    videos: []
  };

  for (const record of records) {
    if (result.title === `分享 ${shareId}` && (record.title || record.name)) {
      result.title = record.title || record.name;
    }
    const messages = record.response_messages || [];
    for (const msg of messages) {
      if (!msg || msg.mime_type !== "multi_load/iframe") continue;
      const multiLoad = (msg.meta_data && msg.meta_data.multi_load) || [];
        for (const item of multiLoad) {
          const content = (item && item.content) || {};
          const prompt = content.prompt || "未知";
          if (result.title === "未知") result.title = prompt;

          const displayList = Array.isArray(content.display_list) ? content.display_list : [];
          const resourceInfos = Array.isArray(content.resource_infos) ? content.resource_infos : [];
          const seenUrls = new Set();
          const knownKindById = new Map();
          const knownKindByUrl = new Map();
          const excludedById = new Set();
          const excludedByUrl = new Set();

          for (const entry of displayList) {
            const videos = Array.isArray(entry.video) ? entry.video : entry.video ? [entry.video] : [];
            const images = Array.isArray(entry.image) ? entry.image : entry.image ? [entry.image] : [];
            const covers = Array.isArray(entry.cover) ? entry.cover : entry.cover ? [entry.cover] : [];
            const downloads = Array.isArray(entry.download_video)
              ? entry.download_video
              : entry.download_video
                ? [entry.download_video]
                : [];
            const watermarks = Array.isArray(entry.watermark_image)
              ? entry.watermark_image
              : entry.watermark_image
                ? [entry.watermark_image]
                : [];

            for (const item of [...downloads, ...watermarks]) {
              if (item && item.id) excludedById.add(item.id);
              if (item && item.url) excludedByUrl.add(item.url);
            }

            for (const video of videos) {
              if (video && video.id) knownKindById.set(video.id, "video");
              if (video && video.url) knownKindByUrl.set(video.url, "video");
            }
            for (const image of [...images, ...covers]) {
              if (image && image.id) knownKindById.set(image.id, "image");
              if (image && image.url) knownKindByUrl.set(image.url, "image");
            }

            for (const video of videos) {
              if (video && typeof video.url === "string" && !seenUrls.has(video.url)) {
                seenUrls.add(video.url);
                result.videos.push({
                  url: video.url,
                  width: null,
                  height: null
                });
              }
            }
            for (const image of [...images, ...covers]) {
              if (image && typeof image.url === "string" && !seenUrls.has(image.url)) {
                seenUrls.add(image.url);
                result.images.push({
                  url: image.url,
                  width: image.width || null,
                  height: image.height || null
                });
              }
            }
          }

          for (const resource of resourceInfos) {
            if (!resource || typeof resource.url !== "string") continue;
            if (excludedById.has(resource.id) || excludedByUrl.has(resource.url)) continue;
            const kind =
              knownKindById.get(resource.id) ||
              knownKindByUrl.get(resource.url) ||
              classifyMediaByUrl(resource.url);
            if (!kind || seenUrls.has(resource.url)) continue;
            seenUrls.add(resource.url);
            if (kind === "video") {
              result.videos.push({
                url: resource.url,
                width: resource.width || null,
                height: resource.height || null
              });
            } else {
              result.images.push({
                url: resource.url,
                width: resource.width || null,
                height: resource.height || null
              });
            }
          }

        }
      }
  }

  return result;
}

async function parseQianwen(url) {
  const linkType = detectLinkType(url);
  if (linkType === "activity") {
    return await parseActivityLink(url);
  }
  return await parseShareChatLink(url);
}

function sanitizeFilename(name) {
  const cleaned = String(name || "")
    .replace(/[\\/:*?"<>|]+/g, "_")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 48);
  return cleaned || "qianwen";
}

function inferImageExtension(url) {
  try {
    const path = new URL(url).pathname.toLowerCase();
    const ext = path.match(/\.(png|jpe?g|webp|gif|bmp|avif)$/);
    return ext ? ext[1] : "jpg";
  } catch (error) {
    return "jpg";
  }
}

function buildFilename(item, index) {
  const prefix = sanitizeFilename(item.title);
  if (item.kind === "image") {
    return `${prefix}_image_${index + 1}.${inferImageExtension(item.url)}`;
  }
  return `${prefix}_video_${index + 1}.mp4`;
}

function downloadFile(item) {
  const url = new URL(item.url).href;
  const filename = buildFilename(item, item.index);
  return new Promise((resolve, reject) => {
    chrome.downloads.download(
      {
        url,
        filename,
        conflictAction: "uniquify",
        saveAs: false
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(downloadId);
      }
    );
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") return false;

  if (message.type === "parse") {
    parseQianwen(message.url)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message.type === "download") {
    downloadFile(message.item)
      .then((downloadId) => sendResponse({ ok: true, downloadId }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message.type === "download:status") {
    const ids = Array.isArray(message.ids) ? message.ids : [];
    if (!ids.length) {
      sendResponse({ ok: true, items: [] });
      return true;
    }
    Promise.all(
      ids.map(
        (id) =>
          new Promise((resolve) => {
            chrome.downloads.search({ id }, (items) => {
              if (chrome.runtime.lastError) {
                resolve(null);
                return;
              }
              const item = items && items[0];
              resolve(
                item
                  ? {
                      id: item.id,
                      state: item.state,
                      bytesReceived: item.bytesReceived || 0,
                      totalBytes: item.totalBytes || 0,
                      filename: item.filename || "",
                      error: item.error || ""
                    }
                  : null
              );
            });
          })
      )
    ).then((items) => sendResponse({ ok: true, items }));
    return true;
  }

  return false;
});
