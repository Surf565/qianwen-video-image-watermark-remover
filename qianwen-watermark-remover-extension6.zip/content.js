(() => {
  if (window.__qianwenWatermarkExtInjected) return;
  window.__qianwenWatermarkExtInjected = true;

  const svgDownload = `
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor"
      stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      <path d="M12 3v12"></path>
      <path d="m7 10 5 5 5-5"></path>
      <path d="M5 21h14"></path>
    </svg>
  `;

  const host = document.createElement("div");
  host.id = "qwm-watermark-host";
  host.style.all = "initial";
  const shadow = host.attachShadow({ mode: "open" });
  document.documentElement.appendChild(host);

  shadow.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; font-family: "Segoe UI", "Microsoft YaHei", system-ui, sans-serif; }
      button, input { font: inherit; }
      button { border: 0; cursor: pointer; }
      .qwm-fab {
        position: fixed;
        right: 0;
        top: 33%;
        z-index: 2147483646;
        display: grid;
        place-items: center;
        width: 48px;
        height: 36px;
        border-radius: 10px 0 0 10px;
        background: #0f766e;
        color: #fff;
        box-shadow: 0 6px 18px rgba(12, 74, 110, 0.32);
        touch-action: none;
        user-select: none;
      }
      .qwm-fab:hover { background: #0b5f59; }
      .qwm-mask {
        position: fixed;
        inset: 0;
        z-index: 2147483646;
        background: rgba(15, 23, 42, 0.42);
      }
      .qwm-modal {
        position: fixed;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        z-index: 2147483647;
        display: flex;
        flex-direction: column;
        width: min(900px, calc(100vw - 32px));
        height: min(680px, calc(100vh - 90px));
        border: 1px solid #dde1e8;
        border-radius: 10px;
        background: #f6f7f9;
        color: #1c2430;
        box-shadow: 0 22px 60px rgba(15, 23, 42, 0.34);
        overflow: hidden;
      }
      .qwm-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 14px;
        background: #fff;
        border-bottom: 1px solid #dde1e8;
        cursor: move;
        user-select: none;
        flex-shrink: 0;
      }
      .qwm-title-wrap { display: flex; align-items: center; gap: 10px; min-width: 0; }
      .qwm-title-wrap strong { font-size: 15px; white-space: nowrap; }
      .qwm-count {
        padding: 3px 8px;
        border-radius: 6px;
        background: #e6f2f0;
        color: #0f766e;
        font-size: 12px;
        white-space: nowrap;
      }
      .qwm-header-actions { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
      .qwm-btn {
        height: 32px;
        padding: 0 12px;
        border-radius: 6px;
        border: 1px solid #dde1e8;
        background: #fff;
        color: #1c2430;
        font-size: 12px;
        font-weight: 600;
      }
      .qwm-btn:hover { border-color: #0f766e; color: #0f766e; }
      .qwm-btn.primary { border-color: #0f766e; background: #0f766e; color: #fff; }
      .qwm-btn.primary:hover { background: #0b5f59; }
      .qwm-close {
        width: 32px;
        padding: 0;
        background: transparent;
        color: #6b7482;
        font-size: 20px;
        line-height: 1;
      }
      .qwm-close:hover { background: #eef1f4; color: #1c2430; }
      .qwm-status {
        min-height: 20px;
        padding: 10px 14px 0;
        color: #6b7482;
        font-size: 12px;
        flex-shrink: 0;
      }
      .qwm-status.error { color: #b42318; }
      .qwm-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 10px 14px 6px;
        flex-shrink: 0;
      }
      .qwm-summary {
        margin: 0;
        overflow: hidden;
        color: #1c2430;
        font-size: 13px;
        font-weight: 600;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .qwm-selected { color: #6b7482; font-size: 12px; white-space: nowrap; }
      .qwm-tabs {
        display: flex;
        gap: 4px;
        padding: 8px 14px 4px;
        flex-shrink: 0;
      }
      .qwm-tab {
        height: 30px;
        padding: 0 12px;
        border-radius: 6px;
        background: transparent;
        color: #6b7482;
        font-size: 12px;
        font-weight: 600;
      }
      .qwm-tab:hover { color: #1c2430; }
      .qwm-tab.active { background: #fff; color: #0f766e; box-shadow: 0 1px 4px rgba(15, 23, 42, 0.14); }
      .qwm-content {
        flex: 1;
        display: grid;
        align-content: start;
        gap: 10px;
        padding: 6px 14px 16px;
        overflow-y: auto;
      }
      .qwm-section-label {
        margin: 4px 0 0;
        color: #6b7482;
        font-size: 12px;
        font-weight: 600;
      }
      .qwm-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
        gap: 10px;
      }
      .qwm-card {
        border: 1px solid #dde1e8;
        border-radius: 8px;
        background: #fff;
        overflow: hidden;
      }
      .qwm-media { position: relative; background: #eef1f4; }
      .qwm-image { display: block; width: 100%; aspect-ratio: 4 / 3; object-fit: cover; }
      .qwm-video { display: block; width: 100%; aspect-ratio: 16 / 9; object-fit: cover; background: #11161d; }
      .qwm-check {
        position: absolute;
        top: 8px;
        right: 8px;
        display: grid;
        place-items: center;
        width: 26px;
        height: 26px;
        border-radius: 6px;
        background: rgba(255, 255, 255, 0.92);
        box-shadow: 0 2px 8px rgba(15, 23, 42, 0.2);
        cursor: pointer;
      }
      .qwm-check input { width: 15px; height: 15px; accent-color: #0f766e; }
      .qwm-card-body { padding: 8px 10px 10px; }
      .qwm-meta { margin: 0 0 6px; color: #1c2430; font-size: 12px; font-weight: 600; }
      .qwm-file {
        margin: 0 0 6px;
        overflow-wrap: anywhere;
        color: #6b7482;
        font-size: 11px;
        line-height: 1.4;
      }
      .qwm-state { min-height: 16px; margin-bottom: 4px; color: #0f766e; font-size: 11px; }
      .qwm-state.done { color: #0b5f59; }
      .qwm-state.error { color: #b42318; }
      .qwm-progress {
        height: 4px;
        margin-bottom: 8px;
        border-radius: 4px;
        background: #e8ebef;
        overflow: hidden;
      }
      .qwm-progress-fill {
        width: 0;
        height: 100%;
        border-radius: 4px;
        background: #0f766e;
        transition: width 0.25s ease;
      }
      .qwm-actions { display: flex; gap: 6px; }
      .qwm-action {
        flex: 1;
        height: 30px;
        border-radius: 6px;
        border: 1px solid #dde1e8;
        background: #fff;
        color: #1c2430;
        font-size: 12px;
      }
      .qwm-action:hover { border-color: #0f766e; color: #0f766e; }
      .qwm-empty {
        padding: 32px 16px;
        border: 1px dashed #dde1e8;
        border-radius: 8px;
        color: #6b7482;
        text-align: center;
        font-size: 13px;
      }
      .qwm-progress-mask {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(15, 23, 42, 0.45);
      }
      .qwm-progress-card {
        width: min(340px, calc(100vw - 48px));
        padding: 22px;
        border-radius: 10px;
        background: #fff;
        box-shadow: 0 18px 50px rgba(15, 23, 42, 0.35);
        text-align: center;
      }
      .qwm-progress-card strong { display: block; margin-bottom: 16px; font-size: 15px; }
      .qwm-progress-track {
        height: 8px;
        border-radius: 8px;
        background: #e8ebef;
        overflow: hidden;
      }
      .qwm-progress-fill-big {
        width: 0;
        height: 100%;
        border-radius: 8px;
        background: #0f766e;
        transition: width 0.25s ease;
      }
      .qwm-progress-text { display: block; margin-top: 10px; color: #6b7482; font-size: 12px; }
      .hidden { display: none !important; }
    </style>

    <button class="qwm-fab" type="button" title="提取无水印媒体" aria-label="提取无水印媒体">${svgDownload}</button>

    <div class="qwm-mask hidden"></div>
    <section class="qwm-modal hidden" role="dialog" aria-modal="true" aria-label="千问无水印提取">
      <header class="qwm-header">
        <div class="qwm-title-wrap">
          <strong>千问无水印提取</strong>
          <span class="qwm-count">解析中…</span>
        </div>
        <div class="qwm-header-actions">
          <button class="qwm-btn qwm-copy-links" type="button">复制链接</button>
          <button class="qwm-btn primary qwm-download-all" type="button">全部下载</button>
          <button class="qwm-close" type="button" aria-label="关闭">×</button>
        </div>
      </header>
      <div class="qwm-status">正在准备…</div>
      <div class="qwm-toolbar hidden">
        <p class="qwm-summary"></p>
        <span class="qwm-selected">已选 0 项</span>
        <button class="qwm-btn qwm-download-selected" type="button">下载选中</button>
      </div>
      <div class="qwm-tabs hidden">
        <button class="qwm-tab active" type="button" data-tab="all">全部</button>
        <button class="qwm-tab" type="button" data-tab="image">图片</button>
        <button class="qwm-tab" type="button" data-tab="video">视频</button>
      </div>
      <div class="qwm-content"></div>
    </section>

    <div class="qwm-progress-mask hidden">
      <div class="qwm-progress-card">
        <strong>正在下载</strong>
        <div class="qwm-progress-track"><div class="qwm-progress-fill-big"></div></div>
        <span class="qwm-progress-text">0 / 0</span>
      </div>
    </div>
  `;

  const fab = shadow.querySelector(".qwm-fab");
  const mask = shadow.querySelector(".qwm-mask");
  const modal = shadow.querySelector(".qwm-modal");
  const header = shadow.querySelector(".qwm-header");
  const closeBtn = shadow.querySelector(".qwm-close");
  const statusEl = shadow.querySelector(".qwm-status");
  const toolbarEl = shadow.querySelector(".qwm-toolbar");
  const summaryEl = shadow.querySelector(".qwm-summary");
  const selectedEl = shadow.querySelector(".qwm-selected");
  const countEl = shadow.querySelector(".qwm-count");
  const tabsEl = shadow.querySelector(".qwm-tabs");
  const tabButtons = [...shadow.querySelectorAll(".qwm-tab")];
  const contentEl = shadow.querySelector(".qwm-content");
  const progressMask = shadow.querySelector(".qwm-progress-mask");
  const progressTitle = shadow.querySelector(".qwm-progress-card strong");
  const progressFill = shadow.querySelector(".qwm-progress-fill-big");
  const progressText = shadow.querySelector(".qwm-progress-text");

  let result = null;
  let parsedUrl = null;
  let downloadJobs = new Map();
  let selectedKeys = new Set();
  let currentTab = "all";
  let statusTimer = null;
  let progressHideTimer = null;
  let isParsing = false;

  function sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(response);
      });
    });
  }

  function esc(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function safeTitle(title) {
    return String(title || "qianwen")
      .replace(/[\\/:*?"<>|]+/g, "_")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 48) || "qianwen";
  }

  function inferImageExtension(url) {
    try {
      const pathname = new URL(url).pathname.toLowerCase();
      const match = pathname.match(/\.(png|jpe?g|webp|gif|bmp|avif)$/);
      return match ? match[1] : "jpg";
    } catch (error) {
      return "jpg";
    }
  }

  function filenameFor(item) {
    const prefix = safeTitle(item.title);
    if (item.kind === "image") {
      return `${prefix}_image_${item.index + 1}.${inferImageExtension(item.url)}`;
    }
    return `${prefix}_video_${item.index + 1}.mp4`;
  }

  function formatBytes(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) return "";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
  }

  function isSharePageUrl(url) {
    return /activity\.qianwen\.com\/|(?:qianwen\.com|qianwen\.my\.cn)\/share\/chat/.test(url || "");
  }

  function isChatPageUrl(url) {
    return /(?:www\.qianwen\.com|qianwen\.com|qianwen\.my\.cn)\/chat(?:\/|$)/.test(url || "");
  }

  function looksLikeMediaUrl(url, kind) {
    if (!url || !/^https?:\/\//i.test(url)) return false;
    const lower = url.toLowerCase();
    if (
      /(g\.alicdn\.com|o\.alicdn\.com|polyfill|\.js(\?|$)|\.css(\?|$)|\.svg(\?|$)|\.woff2?(\?|$)|\.ico(\?|$))/.test(lower)
    ) {
      return false;
    }
    if (/(avatar|logo|favicon|emoji|beacon|aplus|cnzz|stat\.alicdn)/i.test(lower)) {
      return false;
    }
    if (kind === "video") {
      return /\.(mp4|mov|webm|m4v|avi|mkv)(\?|$)/i.test(lower);
    }
    return (
      lower.includes("workspace-zb-cdn.qianwen.com") ||
      lower.includes("auth_key") ||
      /\/resource\//.test(lower) ||
      /\/image\//.test(lower) ||
      /\/imgextra\/i\d+\/O1CN0/i.test(lower) ||
      (/\.(png|jpe?g|webp|gif|avif)(\?|$)/i.test(lower) && /(qianwen|alicdn)/i.test(lower))
    );
  }

  function collectPageMedia() {
    const imageUrls = new Map();
    const videoUrls = new Map();

    const addImage = (url, width, height) => {
      if (!looksLikeMediaUrl(url, "image")) return;
      if (!imageUrls.has(url)) {
        imageUrls.set(url, { url, width: width || null, height: height || null });
      }
    };

    const addVideo = (url) => {
      if (!looksLikeMediaUrl(url, "video")) return;
      if (!videoUrls.has(url)) {
        videoUrls.set(url, { url, width: null, height: null });
      }
    };

    document.querySelectorAll("img").forEach((img) => {
      const url = img.currentSrc || img.src;
      addImage(url, img.naturalWidth || img.width, img.naturalHeight || img.height);
    });

    document.querySelectorAll("video").forEach((video) => {
      addVideo(video.currentSrc || video.src);
    });

    document.querySelectorAll("video source").forEach((source) => {
      addVideo(source.src);
    });

    document.querySelectorAll('a[href]').forEach((link) => {
      addVideo(link.href);
    });

    if (window.performance && typeof performance.getEntriesByType === "function") {
      performance.getEntriesByType("resource").forEach((entry) => {
        addImage(entry.name);
        addVideo(entry.name);
      });
    }

    const title = (document.title || "当前对话")
      .replace(/[-–—]\s*千问.*$/i, "")
      .replace(/\s+/g, " ")
      .trim();

    return {
      title: title || "当前对话",
      images: [...imageUrls.values()],
      videos: [...videoUrls.values()]
    };
  }

  function setStatus(text, mode) {
    statusEl.className = `qwm-status${mode ? ` ${mode}` : ""}`;
    statusEl.textContent = text || "";
  }

  function setProgressModalVisible(visible) {
    progressMask.classList.toggle("hidden", !visible);
  }

  function renderSelection() {
    selectedEl.textContent = `已选 ${selectedKeys.size} 项`;
    const selectedBtn = shadow.querySelector(".qwm-download-selected");
    if (selectedBtn) selectedBtn.disabled = selectedKeys.size === 0;
  }

  function updateTabLabels() {
    const total = (result ? result.images.length + result.videos.length : 0);
    tabButtons.forEach((button) => {
      const tab = button.dataset.tab;
      if (tab === "all") {
        button.textContent = `全部 ${total}`;
      } else if (tab === "image") {
        button.textContent = `图片 ${result ? result.images.length : 0}`;
      } else {
        button.textContent = `视频 ${result ? result.videos.length : 0}`;
      }
    });
  }

  function setTab(tab) {
    currentTab = tab;
    tabButtons.forEach((button) => {
      button.classList.toggle("active", button.dataset.tab === tab);
    });
    contentEl.querySelectorAll("[data-section]").forEach((section) => {
      section.classList.toggle("hidden", tab !== "all" && section.dataset.section !== tab);
    });
  }

  function renderDownloadStates() {
    for (const [key, job] of downloadJobs) {
      const stateEl = shadow.querySelector(`[data-state-key="${key}"]`);
      const fillEl = shadow.querySelector(`[data-progress-key="${key}"]`);
      if (!stateEl) continue;

      if (job.state === "complete") {
        stateEl.textContent = `已完成 · ${formatBytes(job.totalBytes || job.receivedBytes)}`;
        stateEl.className = "qwm-state done";
      } else if (job.state === "interrupted") {
        stateEl.textContent = "下载失败";
        stateEl.className = "qwm-state error";
      } else {
        const percent = job.totalBytes > 0 ? Math.min(99, Math.round((job.receivedBytes / job.totalBytes) * 100)) : 0;
        stateEl.textContent = job.receivedBytes > 0 ? `下载中 ${percent}%` : "等待下载…";
        stateEl.className = "qwm-state";
      }

      if (fillEl) {
        const width = job.state === "complete" ? 100 : job.totalBytes > 0 ? Math.round((job.receivedBytes / job.totalBytes) * 100) : 0;
        fillEl.style.width = `${width}%`;
      }
    }
  }

  function updateProgressModal() {
    const jobs = [...downloadJobs.values()];
    if (!jobs.length) {
      setProgressModalVisible(false);
      return;
    }

    const active = jobs.filter((job) => job.state === "in_progress").length;
    const done = jobs.length - active;
    const percent = jobs.length ? Math.round((done / jobs.length) * 100) : 0;
    progressFill.style.width = `${percent}%`;
    progressText.textContent = `${done} / ${jobs.length}`;

    if (active === 0) {
      progressTitle.textContent = "下载完成";
      if (!progressHideTimer) {
        progressHideTimer = setTimeout(() => {
          setProgressModalVisible(false);
          progressHideTimer = null;
        }, 1400);
      }
    } else {
      progressTitle.textContent = "正在下载";
      if (progressHideTimer) {
        clearTimeout(progressHideTimer);
        progressHideTimer = null;
      }
      setProgressModalVisible(true);
    }
  }

  function trackDownload(item, downloadId) {
    const key = `${item.kind}:${item.index}`;
    downloadJobs.set(key, {
      id: downloadId,
      state: "in_progress",
      receivedBytes: 0,
      totalBytes: 0
    });
    renderDownloadStates();
    updateProgressModal();
    if (!statusTimer) {
      statusTimer = setInterval(refreshDownloadStatus, 1000);
    }
  }

  async function refreshDownloadStatus() {
    if (!downloadJobs.size) return;
    const ids = [...downloadJobs.values()].map((job) => job.id);
    try {
      const response = await sendMessage({ type: "download:status", ids });
      if (!response || !response.ok || !Array.isArray(response.items)) return;
      for (const item of response.items) {
        if (!item) continue;
        const job = [...downloadJobs.values()].find((entry) => entry.id === item.id);
        if (!job) continue;
        job.state = item.state;
        job.receivedBytes = item.bytesReceived || 0;
        job.totalBytes = item.totalBytes || 0;
        job.error = item.error || "";
      }
      renderDownloadStates();
      updateProgressModal();
    } catch (error) {
      // 忽略临时状态查询失败
    }
  }

  function renderResult(data) {
    result = data;
    parsedUrl = location.href;
    selectedKeys.clear();
    downloadJobs.clear();
    contentEl.innerHTML = "";
    toolbarEl.classList.remove("hidden");
    countEl.textContent = `${data.images.length} 张图片 · ${data.videos.length} 个视频`;
    summaryEl.textContent = `${data.title || "未知"} · 共 ${data.images.length + data.videos.length} 个文件`;
    renderSelection();

    if (data.images.length + data.videos.length === 0) {
      contentEl.innerHTML = '<div class="qwm-empty">没有找到可提取的媒体内容</div>';
      tabsEl.classList.add("hidden");
      return;
    }

    tabsEl.classList.remove("hidden");
    currentTab = "all";

    if (data.images.length > 0) {
      const imageSection = document.createElement("div");
      imageSection.className = "qwm-section";
      imageSection.dataset.section = "image";
      const label = document.createElement("p");
      label.className = "qwm-section-label";
      label.textContent = `图片（${data.images.length}）`;
      imageSection.appendChild(label);

      const grid = document.createElement("div");
      grid.className = "qwm-grid";
      data.images.forEach((item, index) => {
        const key = `image:${index}`;
        const meta = item.width && item.height ? `${item.width}×${item.height}` : "原图";
        const filename = filenameFor({ ...item, kind: "image", index, title: data.title });
        const card = document.createElement("article");
        card.className = "qwm-card";
        card.innerHTML = `
          <div class="qwm-media">
            <img class="qwm-image" loading="lazy" src="${esc(item.url)}" alt="无水印图片 ${index + 1}" />
            <label class="qwm-check" title="选择图片">
              <input type="checkbox" data-select="${key}" aria-label="选择图片 ${index + 1}" />
            </label>
          </div>
          <div class="qwm-card-body">
            <p class="qwm-meta">图片 · ${esc(meta)}</p>
            <p class="qwm-file" title="${esc(filename)}">${esc(filename)}</p>
            <div class="qwm-state" data-state-key="${key}">未开始</div>
            <div class="qwm-progress"><div class="qwm-progress-fill" data-progress-key="${key}"></div></div>
            <div class="qwm-actions">
              <button class="qwm-action" data-download="${key}">下载</button>
              <button class="qwm-action" data-copy="${esc(item.url)}">复制链接</button>
            </div>
          </div>
        `;
        grid.appendChild(card);
      });
      imageSection.appendChild(grid);
      contentEl.appendChild(imageSection);
    }

    if (data.videos.length > 0) {
      const videoSection = document.createElement("div");
      videoSection.className = "qwm-section";
      videoSection.dataset.section = "video";
      const label = document.createElement("p");
      label.className = "qwm-section-label";
      label.textContent = `视频（${data.videos.length}）`;
      videoSection.appendChild(label);

      const grid = document.createElement("div");
      grid.className = "qwm-grid";
      data.videos.forEach((item, index) => {
        const key = `video:${index}`;
        const filename = filenameFor({ ...item, kind: "video", index, title: data.title });
        const card = document.createElement("article");
        card.className = "qwm-card";
        card.innerHTML = `
          <div class="qwm-media">
            <video class="qwm-video" controls preload="metadata" src="${esc(item.url)}"></video>
            <label class="qwm-check" title="选择视频">
              <input type="checkbox" data-select="${key}" aria-label="选择视频 ${index + 1}" />
            </label>
          </div>
          <div class="qwm-card-body">
            <p class="qwm-meta">视频</p>
            <p class="qwm-file" title="${esc(filename)}">${esc(filename)}</p>
            <div class="qwm-state" data-state-key="${key}">未开始</div>
            <div class="qwm-progress"><div class="qwm-progress-fill" data-progress-key="${key}"></div></div>
            <div class="qwm-actions">
              <button class="qwm-action" data-download="${key}">下载</button>
              <button class="qwm-action" data-copy="${esc(item.url)}">复制链接</button>
            </div>
          </div>
        `;
        grid.appendChild(card);
      });
      videoSection.appendChild(grid);
      contentEl.appendChild(videoSection);
    }

    updateTabLabels();
    setTab(currentTab);
  }

  async function parseCurrentPage() {
    if (isParsing) return;
    isParsing = true;
    setStatus("正在解析当前分享页…");
    contentEl.innerHTML = "";
    toolbarEl.classList.add("hidden");
    tabsEl.classList.add("hidden");
    fab.disabled = true;
    try {
      if (!isSharePageUrl(location.href)) {
        const media = collectPageMedia();
        renderResult(media);
        setStatus(`已提取当前页面：${media.images.length} 张图片，${media.videos.length} 个视频`);
        return;
      }
      const response = await sendMessage({ type: "parse", url: location.href });
      if (!response || !response.ok) {
        throw new Error(response && response.error ? response.error : "解析失败");
      }
      renderResult(response.result);
      setStatus(`解析完成：${response.result.images.length} 张图片，${response.result.videos.length} 个视频`);
    } catch (error) {
      setStatus(error.message || "解析失败", "error");
      countEl.textContent = "解析失败";
      toolbarEl.classList.add("hidden");
    } finally {
      isParsing = false;
      fab.disabled = false;
    }
  }

  function openModal() {
    mask.classList.remove("hidden");
    modal.classList.remove("hidden");
    if (!result || parsedUrl !== location.href) {
      parseCurrentPage();
    }
  }

  function closeModal() {
    mask.classList.add("hidden");
    modal.classList.add("hidden");
  }

  function itemsByKeys(keys) {
    if (!result) return [];
    const items = [];
    for (const key of keys) {
      const [kind, indexText] = key.split(":");
      const index = Number(indexText);
      const source = kind === "image" ? result.images[index] : result.videos[index];
      if (source) {
        items.push({ ...source, kind, index, title: result.title });
      }
    }
    return items;
  }

  async function downloadItems(items) {
    if (!items.length) return;
    setStatus(`正在创建 ${items.length} 个下载任务…`);
    try {
      for (const item of items) {
        const response = await sendMessage({ type: "download", item });
        if (!response || !response.ok) {
          throw new Error(response && response.error ? response.error : "下载失败");
        }
        trackDownload(item, response.downloadId);
      }
      setStatus(`已开始下载 ${items.length} 个文件`);
    } catch (error) {
      setStatus(error.message || "下载失败", "error");
    }
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      setStatus("链接已复制到剪贴板");
    } catch (error) {
      setStatus("复制失败", "error");
    }
  }

  function initFabDrag() {
    let dragging = false;
    let moved = false;
    let startY = 0;
    let startTop = 0;

    fab.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      dragging = true;
      moved = false;
      startY = event.clientY;
      startTop = parseFloat(fab.style.top) || window.innerHeight * 0.33;
      fab.setPointerCapture(event.pointerId);
    });

    fab.addEventListener("pointermove", (event) => {
      if (!dragging) return;
      const dy = event.clientY - startY;
      if (Math.abs(dy) > 3) moved = true;
      fab.style.top = `${Math.min(window.innerHeight - 40, Math.max(8, startTop + dy))}px`;
    });

    fab.addEventListener("pointerup", () => {
      if (!dragging) return;
      dragging = false;
      if (!moved) openModal();
    });
  }

  function initModalDrag() {
    let active = false;
    let moved = false;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;

    header.addEventListener("mousedown", (event) => {
      if (event.target.closest("button") || event.button !== 0) return;
      const rect = modal.getBoundingClientRect();
      active = true;
      moved = false;
      startX = event.clientX;
      startY = event.clientY;
      startLeft = rect.left;
      startTop = rect.top;
    });

    document.addEventListener("mousemove", (event) => {
      if (!active) return;
      const dx = event.clientX - startX;
      const dy = event.clientY - startY;
      if (!moved && Math.abs(dx) < 4 && Math.abs(dy) < 4) return;
      if (!moved) {
        moved = true;
        modal.style.left = `${startLeft}px`;
        modal.style.top = `${startTop}px`;
        modal.style.transform = "none";
      }
      const left = Math.min(window.innerWidth - 40, Math.max(8, startLeft + dx));
      const top = Math.min(window.innerHeight - 40, Math.max(8, startTop + dy));
      modal.style.left = `${left}px`;
      modal.style.top = `${top}px`;
    });

    document.addEventListener("mouseup", () => {
      active = false;
    });
  }

  fab.addEventListener("click", (event) => event.preventDefault());
  closeBtn.addEventListener("click", closeModal);
  mask.addEventListener("click", closeModal);

  tabButtons.forEach((button) => {
    button.addEventListener("click", () => setTab(button.dataset.tab));
  });

  shadow.querySelector(".qwm-download-all").addEventListener("click", () => {
    if (!result) return;
    const all = [
      ...result.images.map((item, index) => ({ ...item, kind: "image", index, title: result.title })),
      ...result.videos.map((item, index) => ({ ...item, kind: "video", index, title: result.title }))
    ];
    downloadItems(all);
  });

  shadow.querySelector(".qwm-download-selected").addEventListener("click", () => {
    downloadItems(itemsByKeys(selectedKeys));
  });

  shadow.querySelector(".qwm-copy-links").addEventListener("click", () => {
    if (!result) return;
    const links = [...result.images.map((item) => item.url), ...result.videos.map((item) => item.url)].join("\n");
    copyText(links);
  });

  contentEl.addEventListener("change", (event) => {
    const input = event.target.closest("input[data-select]");
    if (!input) return;
    const key = input.dataset.select;
    if (input.checked) {
      selectedKeys.add(key);
    } else {
      selectedKeys.delete(key);
    }
    renderSelection();
  });

  contentEl.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button || !result) return;

    if (button.dataset.copy) {
      copyText(button.dataset.copy);
      return;
    }

    if (button.dataset.download) {
      downloadItems(itemsByKeys([button.dataset.download]));
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !modal.classList.contains("hidden")) {
      closeModal();
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message && message.type === "page:media") {
      sendResponse({ ok: true, result: collectPageMedia() });
    }
    return false;
  });

  initFabDrag();
  initModalDrag();
})();
