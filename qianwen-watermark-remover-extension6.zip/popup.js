const input = document.getElementById("url-input");
const parseBtn = document.getElementById("parse-btn");
const currentBtn = document.getElementById("current-btn");
const clearBtn = document.getElementById("clear-btn");
const statusEl = document.getElementById("status");
const summaryEl = document.getElementById("summary");
const titleText = document.getElementById("title-text");
const countText = document.getElementById("count-text");
const downloadAllBtn = document.getElementById("download-all-btn");
const copyLinksBtn = document.getElementById("copy-links-btn");
const resultsEl = document.getElementById("results");

let currentUrl = "";
let currentTabId = null;
let latestResult = null;
let downloadJobs = new Map();
let statusTimer = null;

function isQianwenShareUrl(value) {
  return /activity\.qianwen\.com\/|(?:qianwen\.com|qianwen\.my\.cn)\/share\/chat/.test(value || "");
}

function isQianwenChatUrl(value) {
  return /(?:www\.qianwen\.com|qianwen\.com|qianwen\.my\.cn)\/chat(?:\/|$)/.test(value || "");
}

function normalizeUrl(value) {
  try {
    const url = new URL(value);
    return `${url.origin}${url.pathname}`;
  } catch (error) {
    return value;
  }
}

function setStatus(message, mode) {
  statusEl.className = `status${mode ? ` ${mode}` : ""}`;
  statusEl.textContent = message || "";
}

function setLoading(isLoading) {
  parseBtn.disabled = isLoading;
  currentBtn.disabled = isLoading || !isQianwenShareUrl(currentUrl);
  if (isLoading) {
    setStatus("正在解析，请稍候…", "loading");
  }
}

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(response);
    });
  });
}

function sendTabMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(response);
    });
  });
}

async function ensureContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
  } catch (error) {
    throw new Error("无法在当前页面启动插件脚本，请刷新页面后重试");
  }
}

function safeTitle(title) {
  return String(title || "qianwen")
    .replace(/[\\/:*?"<>|]+/g, "_")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 48) || "qianwen";
}

function inferImageExtension(url) {
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    const match = pathname.match(/\.(png|jpe?g|webp|gif|bmp|avif)$/);
    return match ? match[1] : "jpg";
  } catch (error) {
    return "jpg";
  }
}

function filenameFor(item) {
  const prefix = safeTitle(item.title);
  if (item.kind === "image") {
    return `${prefix}_image_${item.index + 1}.${inferImageExtension(item.url)}`;
  }
  return `${prefix}_video_${item.index + 1}.mp4`;
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

function renderDownloadStates() {
  for (const [key, job] of downloadJobs) {
    const stateEl = document.querySelector(`[data-state-key="${key}"]`);
    const barEl = document.querySelector(`[data-progress-key="${key}"]`);
    if (!stateEl) continue;

    if (job.state === "complete") {
      stateEl.textContent = `已完成 · ${formatBytes(job.totalBytes || job.receivedBytes)}`;
      stateEl.className = "download-state done";
    } else if (job.state === "interrupted") {
      stateEl.textContent = "下载失败";
      stateEl.className = "download-state error";
    } else {
      const percent = job.totalBytes > 0 ? Math.min(99, Math.round((job.receivedBytes / job.totalBytes) * 100)) : 0;
      stateEl.textContent = job.receivedBytes > 0 ? `下载中 ${percent}%` : "等待下载…";
      stateEl.className = "download-state";
    }

    if (barEl) {
      const width = job.state === "complete" ? 100 : job.totalBytes > 0 ? Math.round((job.receivedBytes / job.totalBytes) * 100) : 0;
      barEl.style.width = `${width}%`;
    }
  }
}

function trackDownload(item, downloadId) {
  const key = `${item.kind}:${item.index}`;
  downloadJobs.set(key, {
    id: downloadId,
    state: "in_progress",
    receivedBytes: 0,
    totalBytes: 0
  });
  if (!statusTimer) {
    statusTimer = setInterval(refreshDownloadStatus, 1000);
  }
  renderDownloadStates();
}

function refreshDownloadStatus() {
  for (const [key, job] of downloadJobs) {
    if (job.state === "complete" || job.state === "interrupted") continue;
    chrome.downloads.search({ id: job.id }, (items) => {
      const item = items && items[0];
      if (!item) return;
      job.state = item.state;
      job.receivedBytes = item.bytesReceived || 0;
      job.totalBytes = item.totalBytes || 0;
      job.error = item.error || "";
      renderDownloadStates();
    });
  }
}

async function parseUrl(url) {
  if (!url || (!isQianwenShareUrl(url) && !isQianwenChatUrl(url))) {
    setStatus("请输入千问分享链接，或打开千问对话页后点击插件图标", "error");
    return;
  }

  if (isQianwenChatUrl(url)) {
    if (!currentTabId || normalizeUrl(url) !== normalizeUrl(currentUrl)) {
      setStatus("请先打开该千问对话页，再点击插件图标解析", "error");
      return;
    }
    await parseChatPage(currentTabId);
    return;
  }

  setLoading(true);
  summaryEl.classList.add("hidden");
  resultsEl.innerHTML = "";
  latestResult = null;
  downloadAllBtn.disabled = true;
  copyLinksBtn.disabled = true;
  downloadJobs.clear();
  if (statusTimer) {
    clearInterval(statusTimer);
    statusTimer = null;
  }

  try {
    const response = await sendMessage({ type: "parse", url });
    if (!response || !response.ok) {
      throw new Error(response && response.error ? response.error : "解析失败");
    }
    latestResult = response.result;
    renderResult(latestResult);
    setStatus(`解析完成：${latestResult.images.length} 张图片，${latestResult.videos.length} 个视频`);
  } catch (error) {
    setStatus(error.message || "解析失败", "error");
  } finally {
    setLoading(false);
  }
}

async function parseChatPage(tabId) {
  setLoading(true);
  summaryEl.classList.add("hidden");
  resultsEl.innerHTML = "";
  latestResult = null;
  downloadAllBtn.disabled = true;
  copyLinksBtn.disabled = true;
  downloadJobs.clear();
  if (statusTimer) {
    clearInterval(statusTimer);
    statusTimer = null;
  }

  try {
    await ensureContentScript(tabId);
    const response = await sendTabMessage(tabId, { type: "page:media" });
    if (!response || !response.ok) {
      throw new Error(response && response.error ? response.error : "无法读取当前页面媒体");
    }
    latestResult = response.result;
    renderResult(latestResult);
    setStatus(`已提取当前页面：${latestResult.images.length} 张图片，${latestResult.videos.length} 个视频`);
  } catch (error) {
    setStatus(error.message || "无法读取当前页面媒体，请刷新页面后重试", "error");
  } finally {
    setLoading(false);
  }
}

function renderResult(result) {
  const imageCount = result.images.length;
  const videoCount = result.videos.length;
  if (imageCount + videoCount === 0) {
    resultsEl.innerHTML = `<div class="empty">没有找到可提取的媒体内容</div>`;
    summaryEl.classList.add("hidden");
    return;
  }

  titleText.textContent = result.title || "未知";
  countText.textContent = `${imageCount} 张图片 · ${videoCount} 个视频`;
  summaryEl.classList.remove("hidden");
  downloadAllBtn.disabled = false;
  copyLinksBtn.disabled = false;

  const blocks = [];
  if (imageCount > 0) {
    blocks.push(`<p class="section-label">图片（${imageCount}）</p>`);
    blocks.push('<div class="image-grid">');
    result.images.forEach((item, index) => {
      const meta = item.width && item.height ? `${item.width}×${item.height}` : "原图";
      const filename = filenameFor({ ...item, kind: "image", index, title: result.title });
      blocks.push(`
        <article class="card image-card">
          <img class="media" loading="lazy" src="${esc(item.url)}" alt="无水印图片 ${index + 1}" />
          <div class="card-body">
            <p class="card-meta" title="${esc(meta)}">图片 · ${esc(meta)}</p>
            <p class="file-line" title="${esc(filename)}">${esc(filename)}</p>
            <div class="download-state" data-state-key="image:${index}">未开始</div>
            <div class="progress"><div class="progress-bar" data-progress-key="image:${index}"></div></div>
            <div class="card-actions">
              <button class="card-action" data-kind="image" data-index="${index}">下载</button>
              <button class="card-action" data-copy="${esc(item.url)}">复制链接</button>
            </div>
          </div>
        </article>
      `);
    });
    blocks.push("</div>");
  }

  if (videoCount > 0) {
    blocks.push(`<p class="section-label">视频（${videoCount}）</p>`);
    result.videos.forEach((item, index) => {
      const filename = filenameFor({ ...item, kind: "video", index, title: result.title });
      blocks.push(`
        <article class="card video-card">
          <video controls preload="metadata" src="${esc(item.url)}"></video>
          <p class="card-meta">视频</p>
          <p class="file-line" title="${esc(filename)}">${esc(filename)}</p>
          <div class="download-state" data-state-key="video:${index}">未开始</div>
          <div class="progress"><div class="progress-bar" data-progress-key="video:${index}"></div></div>
          <div class="card-actions">
            <button class="card-action" data-kind="video" data-index="${index}">下载</button>
            <button class="card-action" data-copy="${esc(item.url)}">复制链接</button>
          </div>
        </article>
      `);
    });
  }

  resultsEl.innerHTML = blocks.join("");
}

async function downloadItem(item) {
  const response = await sendMessage({ type: "download", item });
  if (!response || !response.ok) {
    throw new Error(response && response.error ? response.error : "下载失败");
  }
  if (response.downloadId != null) {
    trackDownload(item, response.downloadId);
  }
  return response;
}

async function downloadAll() {
  if (!latestResult) return;
  const items = [];
  latestResult.images.forEach((item, index) => {
    items.push({ ...item, kind: "image", index, title: latestResult.title });
  });
  latestResult.videos.forEach((item, index) => {
    items.push({ ...item, kind: "video", index, title: latestResult.title });
  });

  downloadAllBtn.disabled = true;
  setStatus("正在创建下载任务…", "loading");
  try {
    for (const item of items) {
      await downloadItem(item);
    }
    setStatus(`已开始下载 ${items.length} 个文件`);
  } catch (error) {
    setStatus(error.message || "下载失败", "error");
  } finally {
    downloadAllBtn.disabled = false;
  }
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (error) {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
  }
}

async function copyAllLinks() {
  if (!latestResult) return;
  const links = [
    ...latestResult.images.map((item) => item.url),
    ...latestResult.videos.map((item) => item.url)
  ].join("\n");
  await copyText(links);
  setStatus("链接已复制到剪贴板");
}

parseBtn.addEventListener("click", () => parseUrl(input.value.trim()));

currentBtn.addEventListener("click", () => parseUrl(currentUrl));

clearBtn.addEventListener("click", () => {
  input.value = "";
  currentUrl = "";
  latestResult = null;
  downloadJobs.clear();
  if (statusTimer) {
    clearInterval(statusTimer);
    statusTimer = null;
  }
  summaryEl.classList.add("hidden");
  resultsEl.innerHTML = "";
  setStatus("");
  currentBtn.disabled = true;
  input.focus();
});

resultsEl.addEventListener("click", async (event) => {
  const button = event.target.closest("button");
  if (!button || !latestResult) return;

  if (button.dataset.copy) {
    await copyText(button.dataset.copy);
    setStatus("链接已复制到剪贴板");
    return;
  }

  if (button.dataset.kind) {
    const kind = button.dataset.kind;
    const index = Number(button.dataset.index);
    const source = kind === "image" ? latestResult.images[index] : latestResult.videos[index];
    if (!source) return;
    button.disabled = true;
    try {
      await downloadItem({
        ...source,
        kind,
        index,
        title: latestResult.title
      });
      setStatus("下载任务已创建");
    } catch (error) {
      setStatus(error.message || "下载失败", "error");
    } finally {
      button.disabled = false;
    }
  }
});

input.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    parseUrl(input.value.trim());
  }
});

if (chrome.downloads && chrome.downloads.onChanged) {
  chrome.downloads.onChanged.addListener((delta) => {
    for (const [, job] of downloadJobs) {
      if (job.id !== delta.id) continue;
      if (delta.state) job.state = delta.state.currentValue;
      if (delta.bytesReceived) job.receivedBytes = delta.bytesReceived.currentValue;
      if (delta.totalBytes) job.totalBytes = delta.totalBytes.currentValue;
      if (delta.error) job.error = delta.error.currentValue;
      renderDownloadStates();
    }
  });
}

window.addEventListener("unload", () => {
  if (statusTimer) {
    clearInterval(statusTimer);
    statusTimer = null;
  }
});

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs && tabs[0];
  if (tab && tab.url) {
    currentUrl = tab.url;
    currentTabId = tab.id;
    if (isQianwenShareUrl(currentUrl) || isQianwenChatUrl(currentUrl)) {
      input.value = currentUrl;
      currentBtn.disabled = false;
      parseUrl(currentUrl);
    } else {
      setStatus("打开千问分享页或对话页后，插件会自动读取媒体");
    }
  }
});
